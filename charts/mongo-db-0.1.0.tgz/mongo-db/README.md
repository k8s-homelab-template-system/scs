# mongo-db

Helm chart chạy MongoDB trên Kubernetes. Chart này không tự viết template mà dùng lại chart [`bitnami/mongodb`](https://artifacthub.io/packages/helm/bitnami/mongodb) (20.0.5, lấy từ `oci://registry-1.docker.io/bitnamicharts`) làm dependency.

Cấu hình mặc định (xem [values.yaml](values.yaml)):

- MongoDB 9, chạy 1 instance (`standalone`, StatefulSet), ổ 5Gi dùng StorageClass mặc định
- User `root` và user `app` (quyền trên database `app`)
- Không bật metrics

> **Lưu ý về image:** từ 2025 Bitnami chỉ phát hành miễn phí tag `latest` của image `bitnami/mongodb`, nên chart này đang chạy `mongodb:latest`. Image sẽ thay đổi mỗi khi pod được tạo lại. Nếu cần cố định, hãy ghi đè `mongodb.image.digest` bằng digest cụ thể.

## Cài đặt

```bash
helm dependency build .
helm upgrade --install mongo-db . --namespace homelab --create-namespace
```

Thường thì chart này được cài qua umbrella chart `scs` chứ không cài riêng.

## Kết nối

Với release tên `<release>`, chart tạo:

| Resource | Tên |
| --- | --- |
| Service | `<release>-mongodb` (port 27017) |
| Secret | `<release>-mongodb-auth` (key `mongodb-root-password` cho user `root`, `mongodb-passwords` cho user `app`) |

Lấy mật khẩu của user `app`:

```bash
kubectl get secret <release>-mongodb-auth -n homelab -o jsonpath='{.data.mongodb-passwords}' | base64 -d
```

Chuỗi kết nối trong cluster:

```
mongodb://app:<password>@<release>-mongodb.homelab.svc.cluster.local:27017/app
```

## Credential

Mật khẩu nằm trong Secret `<release>-mongodb-auth`, do chart này tạo ([templates/auth-secret.yaml](templates/auth-secret.yaml)). Không có credential nào trong git.

- Sinh ngẫu nhiên khi cài lần đầu, giữ nguyên khi upgrade (`lookup` Secret đang có).
- `mongodb-passwords` là danh sách mật khẩu cách nhau bởi dấu phẩy, theo thứ tự `mongodb.auth.usernames`. Thêm user mới vào cuối danh sách thì user cũ giữ mật khẩu, user mới được sinh mật khẩu.
- Có annotation `helm.sh/resource-policy: keep`: gỡ release vẫn giữ Secret, cài lại dùng đúng mật khẩu cũ.

Tự quản lý Secret (kubectl, Sealed Secrets, External Secrets...): đặt `authSecret.create: false` và tạo Secret tên `<release>-mongodb-auth` với 2 key trên, hoặc trỏ `mongodb.auth.existingSecret` sang tên khác.
